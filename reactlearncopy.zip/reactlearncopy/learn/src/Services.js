function Services() {
    return ( 
        <section id="services">
        <div className="container">
            <div className="row">
                <h2>Services</h2>
                <div className="col-md-3">
                    <img src="media/snapchat-icon.png" alt="" />
                    <h4>Service-1</h4>
                    <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Eius nobis eos repellat amet quod, dolores atque illo sequi et! Nihil dolorem odit velit voluptatem consequatur.</p>
                    <button className="btn btn-success">More Details.....</button>
                </div>
                <div className="col-md-3">
                    <img src="media/snapchat-icon.png" alt="" />
                    <h4>Service-2</h4>
                    <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Eius nobis eos repellat amet quod, dolores atque illo sequi et! Nihil dolorem odit velit voluptatem consequatur.</p>
                    <button className="btn btn-success">More Details.....</button>
                </div>
                <div className="col-md-3">
                    <img src="media/snapchat-icon.png" alt="" />
                    <h4>Service-3</h4>
                    <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Eius nobis eos repellat amet quod, dolores atque illo sequi et! Nihil dolorem odit velit voluptatem consequatur.</p>
                    <button className="btn btn-success">More Details.....</button>
                </div>
                <div className="col-md-3">
                    <img src="media/snapchat-icon.png" alt="" />
                    <h4>Service-4</h4>
                    <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Eius nobis eos repellat amet quod, dolores atque illo sequi et! Nihil dolorem odit velit voluptatem consequatur.</p>
                    <button className="btn btn-success">More Details.....</button>
                </div>
            </div>
        </div>
    </section>
     );
}

export default Services;