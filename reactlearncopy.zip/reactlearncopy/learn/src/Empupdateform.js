import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

function Empupdateform() {

    const[firstName,setFirstName]=useState('')
    const[lastName,setLastName]=useState('')
    const[email,setEmail]=useState('')
    const[message,setMessage]=useState('')
    const navigate=useNavigate()

    const {id}=useParams()
    //console.log(id)
    useEffect(()=>{
        fetch(`/api/singledata/${id}`).then((result)=>{return result.json()}).then((data)=>{
            //console.log(data)
            if(data.status===200){
                setFirstName(data.apiData.fname)
                setLastName(data.apiData.lname)
                setEmail(data.apiData.email)
            }else{
                setMessage(data.message)
            }
        }) //variable and string ko ek sath bhejna
    },[])
     
    function handleform(e){
        e.preventDefault()
        //console.log(firstName,lastName,email)
        const data={firstName,lastName,email}
        fetch(`/api/empupdate/${id}`,{
            method:"PUT",
            headers:{"Content-Type":"application/json"},
            body:JSON.stringify(data)
        }).then((result)=>{return result.json()}).then((data)=>{
            //console.log(data)
            if(data.status===200){
                setMessage(data.message)
                alert(data.message)
                navigate('/selection')
            }else{
                setMessage(data.message)
            }
        })

    }


    return ( 
        <>
        <h2>Emp Details Update Form {id} </h2>
        <p>{message}</p>
        <form onSubmit={(e)=>{handleform(e)}}>
            <label>First Name</label>
            <input type="text"
            value={firstName} 
            onChange={(e)=>{setFirstName(e.target.value)}}
            />
            <label>Last Name</label>
            <input type="text"
            value={lastName}
            onChange={(e)=>{setLastName(e.target.value)}}
            />
            <label>Email</label>
            <input type="text"
            value={email} 
            onChange={(e)=>{setEmail(e.target.value)}}
            />
            <button type="submit">Update</button>
        </form>
        </>
     );
}

export default Empupdateform;