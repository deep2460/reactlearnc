function Banner() {
    return ( 
        <section id="banner">
        <div className="container">
            <div className="row">
                <div className="col-md-8">
                    <h4>Banner Title</h4>
                    <p> description Lorem ipsum dolor sit amet consectetur adipisicing elit. Quibusdam, amet. Repellendus tempore rem animi est, reiciendis non expedita sed repudiandae!</p>
                    <a href="/"><button className="btn btn-success">more details....</button></a>
                </div>
                <div className="col-md-4">
                    <img src="media/about-us.png" alt="" id="banner-img" className="img-fluid  d-block mx-auto" />
                </div>
            </div>
        </div>
        <img src="media/border1.png" alt="" />

    </section>
     );
}

export default Banner;