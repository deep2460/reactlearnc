import Banner from "./Banner";
import Services from "./Services";
import Testi from "./Testi";

function Mid() {
    return ( 
        <>
        <Banner/>
        <Services/>
        <Testi/>
        </>
     );
}

export default Mid;