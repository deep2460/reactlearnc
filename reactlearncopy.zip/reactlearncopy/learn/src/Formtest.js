import { useState } from "react";
import { useNavigate } from "react-router-dom";

function Formtest() {
    const[firstName,setFirstName]=useState('')
    const[lastName,setLastName]=useState('')
    const[email,setEmail]=useState('')
    const[message,setMessage]=useState('')
    let navigate=useNavigate()
    
      
     function handleform(e){
        e.preventDefault()
        const data={firstName,lastName,email}
        fetch("/api/empincert",{
         method:"POST",
         headers:{"Content-Type":"application/json"},
         body:JSON.stringify(data)
        }).then((result)=>{return result.json()}).then((data)=>{
         console.log(data)
         if(data.status===201){
         setMessage(data.message)
         navigate('/selection')
         }else{
            setMessage(data.message)
         }

        })
        
     }

    return ( 
        <>
        <h2>Form Concept</h2>
        <p>{message}</p> 
        <form onSubmit={(e)=>{handleform(e)}}>
          <label>First Name</label>
          <input type="text"
          value={firstName}
          onChange={(e)=>{setFirstName(e.target.value)}}
          />
          <label>Last Name</label>
          <input type="text"
          value={lastName}
          onChange={(e)=>{setLastName(e.target.value)}}
          />
          <label>Email</label>
          <input type="text"
          value={email}
          onChange={(e)=>{setEmail(e.target.value)}}
          />
          <button type="submit">submit</button>
         </form>
        </>
     );
}

export default Formtest;