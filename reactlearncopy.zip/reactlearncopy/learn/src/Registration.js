import { useState } from "react";

function Reg() {
    const[username,setUsername]=useState('')
    const[password,setPassword]=useState('')
    const[message,setMessage]=useState('')

    function handleform(e){
        e.preventDefault()
        //console.log(username,password)
        const data={username,password}
        fetch('/api/reg',{
            method:"POST",
            headers:{"Content-Type":"application/json"},
            body:JSON.stringify(data)
        }).then((result)=>{return result.json()}).then((data)=>{
            //console.log(data)
            if(data.status===201){
                  setMessage('username is successfully registered')
            }else{
                  setMessage(data.message)
            }
        })
        
    }
    
    return ( 
        <>
        <h2>Registration Here</h2>
        <p>{message}</p>
        <form onSubmit={(e)=>{handleform(e)}}>
           <label>Username</label>
           <input type="text" 
           value={username}
           onChange={(e)=>{setUsername(e.target.value)}}
           />
           <label>Password</label>
           <input type="text" 
           value={password}
           onChange={(e)=>{setPassword(e.target.value)}}
           />
           <button type="submit">Sign up</button>
        </form>
        </>
     );
}

export default Reg;