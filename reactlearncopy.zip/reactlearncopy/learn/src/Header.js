import { Link } from "react-router-dom";

function Header() {

    return (
        <section id="header">
        <div className="container">
            <div className="row">
                <div className="col-md-12">
                    <nav className="navbar navbar-expand-lg">
                        <div className="container-fluid">
                          <img src="/media/logo.png" alt=""/>
                          <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                            <i className="bi bi-list"></i>
                          </button>
                          <div className="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul className="navbar-nav ms-auto">
                              <li className="nav-item">
                                <Link className="nav-link active" aria-current="page" to="/">Home</Link>
                              </li>
                              <li className="nav-item">
                                <Link className="nav-link" to="/variable">Variable Concept</Link>
                              </li>
                              <li className="nav-item">
                                <Link className="nav-link" to="/formtest">Form</Link>
                              </li>
                              <li className="nav-item">
                                <Link className="nav-link" to="/selection">Selection</Link>
                              </li>
                              <li className="nav-item">
                                <Link className="nav-link" to="/reg">Registration</Link>
                              </li>
                              <li className="nav-item">
                                <Link className="nav-link" to="/login">Login</Link>
                              </li>
                              
                              
                            </ul>
                          </div>
                        </div>
                      </nav>
                </div>
            </div>
        </div>
    </section>
    )

}

export default Header;