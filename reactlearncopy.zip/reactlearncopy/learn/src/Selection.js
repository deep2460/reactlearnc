import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";

function Selection() {
  let navigate=useNavigate()
  
    const[empdata,setEmpData]=useState([])
    const[message,setMessage]=useState()

    
    useEffect(()=>{
        fetch('/api/empdata').then((result)=>{return result.json()}).then((data)=>{
            //console.log(data)
            if(data.status===200){
                setEmpData(data.apiData)
                
            }else{
                 setMessage(data.message)
            }
        })
    },[])

    function handledelete(e,id){
      //console.log(id)
      fetch(`/api/empdelete/${id}`,{
        method:"DELETE"
      }).then((result)=>{return result.json()}).then((data)=>{
        //console.log(data)
        if(data.status===200){
          alert(data.message)
          //setMessage(data.message)
          navigate('/selection')
        }else{
          setMessage(data.message)
        }
      })
    }

    return ( 
        <>
        <h2>Selection page</h2>
        <p>{message}</p>
        <table className="table table-hover">
            <thead>
              <tr>
                <th>S.no</th>
                <th>Emp First Name</th>
                <th>Emp Last Name</th>
                <th>Email</th>
                <th>Action</th>
                <th>Action</th>
                
              </tr>
            </thead>
            <tbody>
                {empdata.map((result,key)=>(
                  <tr key={result._id}>
                    <td>{key+1}</td>
                    <td>{result.fname}</td>
                    <td>{result.lname}</td>
                    <td>{result.email}</td>
                    <td><Link to={`/update/${result._id}`}><button>Update</button></Link></td>
                    <td><button onClick={(e)=>{handledelete(e,result._id)}}>Delete</button></td>
                  </tr>
                ))}
            
            </tbody>
        </table>
        </>
     );
}

export default Selection;