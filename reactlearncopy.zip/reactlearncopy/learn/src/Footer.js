import { Link } from "react-router-dom";

function Footer() {
    return ( 
        <section id="footer">
        <img src="/media/border2.png" id="border-img" alt="" />
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <img src="/media/logo.png" alt="" />
                    <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Repudiandae, adipisci. ipsum dolor sit amet consectetur adipisicing elit. Eos mollitia ipsum officia autem temporibus voluptas exercitationem commodi! Molestias autem, voluptate eveniet quam error maiores explicabo ullam pariatur consequatur qui recusandae iure odit exercitationem iusto perspiciatis eum hic dolorum accusamus accusantium. Nihil soluta necessitatibus eos, sint deserunt at? Magni, est debitis?</p>
                </div>
                <div class="col-md-4">
                    <h2>Indigo Pvt. Ltd.</h2>
                    <table>
                        <tr>
                            <td><span><i class="bi bi-buildings"></i></span></td>
                            <td><p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Culpa dolore officiis porro totam qui delectus sit adipisci animi cumque reiciendis.</p></td>
                        </tr>
                        <tr>
                            <td><span><i class="bi bi-telephone"></i></span></td>
                            <td><p>05643-272349</p></td>
                        </tr>
                        <tr>
                            <td><span><i class="bi bi-phone"></i></span></td>
                            <td><p>+91-9680201729</p></td>
                        </tr>
                        <tr>
                            <td><span><i class="bi bi-envelope"></i></span></td>
                            <td><p>deepakdhaked21@gmail.com</p></td>
                        </tr>
                    </table>
                </div>
                <div class="col-md-4">
                    <h2>Query Form</h2>
                    <form action="" method="post">
                        <input type="email" name="" id="" placeholder="Enter Email" class="form-control form-control-lg" />
                        <textarea name="" id="" placeholder="Enter Query" class="form-control form-control-lg mt-2 mb-2"></textarea>
                        <button type="submit" class="btn btn-success form-control mt-3">Post</button>
                    </form>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row text-center">
                <div class="col-md-12">
                    <Link to=""><img src="/media/instagram-icon.png" alt="" /></Link>
                    <Link to=""><img src="/media/linkedin-icon.png" alt="" /></Link>
                    <Link to=""><img src="/media/snapchat-icon.png" alt="" /></Link>
                    <Link to=""><img src="/media/twitter-icon.png" alt="" /></Link>
                </div>
            </div>
        </div>
    </section>
     );
}

export default Footer;