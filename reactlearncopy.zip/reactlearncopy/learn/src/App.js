import { BrowserRouter as Router,Route,Routes } from 'react-router-dom'
import Footer from './Footer';
import Header  from './Header.js'
import Mid from './Mid';
import Variable from './Variable'
import Formtest from './Formtest';
import Selection from './Selection';
import Empupdateform from './Empupdateform';
import Reg from './Registration';
import Login from './Login';

function App() {
    return ( 
        <>
        <Router>
        <Header/>
        <Routes>
        <Route path='/' element={<Mid/>}></Route>
        <Route path='/variable' element={<Variable/>}></Route>
        <Route path='/formtest' element={<Formtest/>}></Route>
        <Route path='/selection' element={<Selection/>}></Route>
        <Route path='/update/:id' element={<Empupdateform/>}></Route>
        <Route path='/reg' element={<Reg/>}></Route>
        <Route path='/login' element={<Login/>}></Route>
        
        </Routes>
        <Footer/>
        </Router>
        </>
     );
}

export default App;