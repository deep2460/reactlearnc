import { useState } from "react";

function Variable() {
   let[counter,setCounter]=useState(0)
   function handleincrement(e){
    setCounter(++counter)
    //console.log(counter)
   }
    function handledecrement(e){
     setCounter(--counter)
     //console.log(counter)
    }
    return (
        <>
        <button onClick={(e)=>{handleincrement(e)}}>+</button>{counter}<button onClick={(e)=>{handledecrement(e)}}>-</button>
        </>
     )
}

export default Variable;