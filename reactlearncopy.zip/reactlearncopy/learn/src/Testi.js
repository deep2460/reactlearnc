function Testi() {
    return ( 
        <section id="testi">
        <div className="container">
            <div className="row">
                <h2>testinominals</h2>
                <div className="col-md-3">
                    <img src="media/instagram-icon.png" alt="" />
                    <p><span><i className="bi bi-quote"></i></span>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ratione accusamus illum perspiciatis fugiat vel autem harum facere libero beatae distinctio.<span><i className="bi bi-quote"></i></span></p>
                    <h4>IBM IND PVT LTD</h4>
                </div>
                <div className="col-md-3">
                    <img src="media/instagram-icon.png" alt="" />
                    <p><span><i className="bi bi-quote"></i></span>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ratione accusamus illum perspiciatis fugiat vel autem harum facere libero beatae distinctio.<span><i className="bi bi-quote"></i></span></p>
                    <h4>IBM IND PVT LTD</h4>
                </div>
                <div className="col-md-3">
                    <img src="media/instagram-icon.png" alt="" />
                    <p><span><i className="bi bi-quote"></i></span>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ratione accusamus illum perspiciatis fugiat vel autem harum facere libero beatae distinctio.<span><i className="bi bi-quote"></i></span></p>
                    <h4>IBM IND PVT LTD</h4>
                </div>
                <div className="col-md-3">
                    <img src="media/instagram-icon.png" alt="" />
                    <p><span><i className="bi bi-quote"></i></span>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ratione accusamus illum perspiciatis fugiat vel autem harum facere libero beatae distinctio.<span><i className="bi bi-quote"></i></span></p>
                    <h4>IBM IND PVT LTD</h4>
                </div>
            </div>
        </div>
    </section>
     );
}

export default Testi
;