import { useState } from "react";

function Login() {
    const[username,setUsername]=useState('')
    const[password,setPassword]=useState('')

    function handleform(e){
         e.preventDefault()
        // console.log(username,password)
        const data={username,password}
        fetch('/api/login',{
            method:"POST",
            headers:{"Content-Type":"application/json"},
            body:JSON.stringify(data)
        })
    }
    return ( 

        <>
        <h2>Login here</h2>
        <form onSubmit={(e)=>{handleform(e)}}>
            <label>Username</label>
            <input type="text" 
            value={username}
            onChange={(e)=>{setUsername(e.target.value)}}
            />
            <label>Password</label>
            <input type="text" 
             value={password}
             onChange={(e)=>{setPassword(e.target.value)}}
            />
            <button type="submit">Login</button>
        </form>
        </>
     );
}

export default Login;