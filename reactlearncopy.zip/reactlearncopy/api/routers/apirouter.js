const router=require('express').Router()
const empc=require('../controllers/empcontroller')
const regc=require('../controllers/regcontroller')


router.post('/empincert',empc.empinsert)
router.get('/empdata',empc.empdata)
router.get('/singledata/:id',empc.empsingledata)
router.put('/empupdate/:id',empc.empupdate)
router.delete('/empdelete/:id',empc.empdelete)
router.post('/reg',regc.register)
router.post('/login',regc.login)








module.exports=router