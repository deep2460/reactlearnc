const Emp=require('../models/emp')

exports.empinsert=(req,res)=>{
    //console.log(req.body)
    const{firstName,lastName,email}=req.body
    try{
    const record=new Emp({ fname:firstName,lname:lastName,email:email})
    record.save()
    //console.log(record)
    res.json({
        status:201,
        message:'record hasbeen successfully inserted',
        apiData:record   
    })
    }catch(error){
      res.json({
        status:400,
        message:error.message
      })
    }
    
}

exports.empdata=async(req,res)=>{
  try{
  const record=await Emp.find()
  //console.log(record)
  res.json({
    status:200,
    apiData:record
  })
  }catch(error){
    res.json({
      status:500,
    message:error.message
    })

  }
}

exports.empsingledata=async(req,res)=>{
  //console.log(req.params.id)
  try{
  const id=req.params.id
  const record=await Emp.findById(id)
  //console.log(record)
  res.json({
    status:200,
    apiData:record
  })
  }catch(error){
    res.json({
      status:500,
      message:error.message
    })
  }
}

exports.empupdate=async(req,res)=>{
  //console.log(req.params.id)
  //console.log(req.body)
  try{
  const id=req.params.id
  const {firstName,lastName,email}=req.body
  await Emp.findByIdAndUpdate(id,{fname:firstName,lname:lastName,email:email})
  //console.log(record)
  res.json({
    status:200,
    message:'successfully updated'
  })
  }catch(error){
    res.json({
      status:500,
      message:error.message
    })
  }

}

exports.empdelete=async(req,res)=>{
  //console.log(req.params.id)
  const id=req.params.id
  try{
  await Emp.findByIdAndDelete(id)
  res.json({
    status:200,
    message:"successfully deleted"
  })
}catch(error){
  res.json({
    status:500,
    message:error.message
  })
    
}
}
 
  


