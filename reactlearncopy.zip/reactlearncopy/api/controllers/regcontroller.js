const Reg=require('../models/reg')




exports.register=async(req,res)=>{
    //console.log(req.body)
    try{
    const{username,password}=req.body
    const usercheck=await Reg.findOne({username:username})
    //console.log(usercheck)
    if(usercheck==null){
    const record=new Reg({ username:username,password:password})
    record.save()
    //console.log(record)
    res.json({
        status:201,
        apiData:record
    })
    }else{
        res.json({
            status:400,
            message:'usename already registered with us'
        })
    }
    }catch(error){
        res.json({
            status:400,
            message:error.message
        })
    }
}

exports.login=(req,res)=>{
    console.log(req.body)
}