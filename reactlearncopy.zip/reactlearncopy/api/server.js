const express=require('express')//function
const app=express()//module
app.use(express.json())
const apiRouter=require('../api/routers/apirouter')
const mongoose=require('mongoose')//module
mongoose.connect('mongodb://127.0.0.1:27017/reactlearn')









app.use('/api',apiRouter)
app.listen(5000,()=>{console.log('Server is running on port 5000')})