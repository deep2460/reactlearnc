const mongoose=require('mongoose')

const empSchema=mongoose.Schema({
    fname:String,
    lname:String,
    email:String
})







module.exports=mongoose.model('emp',empSchema)